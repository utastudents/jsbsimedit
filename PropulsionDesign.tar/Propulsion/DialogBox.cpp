#ifndef DIALOGBOX_H
#define DIALOGBOX_H

class DialogBox {
public:
    void show();
    void close();
};

#endif // DIALOGBOX_H
